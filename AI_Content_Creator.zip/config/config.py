import os
from utils.file_utility import FileUtility
from utils.general_utilities import GeneralUtility


class Config:
    """
    Anime, Concept Art, Photo Realistic, Cartoon, Sketch, Anime Sketch, Anime Photo Realism, Colored Pencil Art,
    Crayon Art, Digital Art, Oil Painting, Dutch Golden Age, Hyper Realism, Graffiti, Magic Realism, Photorealism,
    Realism, Retrowave, Street Art, Surrealism, Dreamworks, Gothic, Fantastic Planet, Interstellar, Space, Naturalism,
    Manga, Optical Illusion, Pixel Art, Cinematic
    """
    STYLE = 'photorealistic'
    # landscape, portrait
    CAMERA_TYPE = 'portrait'
    # wide angle, medium angle, close up
    # CAMERA_LENS_TYPE = 'wide angle'
    INPUT_STORY = FileUtility.get_real_path(os.path.join(os.getcwd(), 'input', 'story.txt'))
    INPUT_INTRO_VIDEO = FileUtility.get_real_path(os.path.join(os.getcwd(), 'input', 'intro.mp4'))
    CURRENT_OUTPUT_DIR = FileUtility.get_real_path(os.path.join(os.getcwd(), 'output', GeneralUtility.get_date_time()))
    ELEVEN_LABS_CACHE = FileUtility.get_real_path(os.path.join(os.getcwd(), 'config', 'eleven_labs_cache.json'))
    CHATGPT_CACHE = FileUtility.get_real_path(os.path.join(os.getcwd(), 'config', 'chatgpt_cache.json'))
    BING_CACHE = FileUtility.get_real_path(os.path.join(os.getcwd(), 'config', 'bing_cache.json'))
    TEMP_FILE = os.path.join(CURRENT_OUTPUT_DIR, 'temp.txt')
    MAX_SPLIT_LENGTH = 3000
    AUDIO_SEQUENCE_PREFIX = 'audio_'
    VIDEO_SEQUENCE_PREFIX = 'video_'
    IMAGE_SEQUENCE_PREFIX = 'image_'
    OUTPUT_VIDEO_FILE = os.path.join(CURRENT_OUTPUT_DIR, 'output.mp4')
    VIDEO_FPS = 30
    BING_IMAGE_CREATOR_RESULTS_LEN = 4
    IMAGE_RESOLUTION = (1080, 1920)
    IMAGE_PROMPT_MAX_MODIFIERS = 7
    ELEVEN_LABS_VOICES = [
        'Rachel',
        'Domi',
        'Bella',
        'Antoni',  # Pref 2
        'Elli',
        'Josh',  # Pref 1
        'Arnold',  # Pref 3
        'Adam',
        'Sam'
    ]
    ELEVEN_LABS_PREFERRED_VOICE = 'Antoni'
    EDIT_PROMPTS = False
    ANIMATE_VIDEO = True
