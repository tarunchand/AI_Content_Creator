class VisualAudioMixer:
    def __init__(self):
        pass

    def convert(self, image_path, audio_path):
        pass


class AnimationMixer(VisualAudioMixer):
    def __init__(self, animator):
        super().__init__()
        self.animator = animator

    def convert(self, image_path, audio_path):
        pass
