class PromptTemplate:
    def __int__(self):
        pass

    def get_prompt(self, text):
        pass
