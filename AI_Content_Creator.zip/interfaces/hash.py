class Hash:
    def __init__(self):
        pass

    def hash(self, data):
        pass
