class VideoAssembler:
    def __init__(self):
        pass

    def assemble(self, video_parts_path):
        pass
