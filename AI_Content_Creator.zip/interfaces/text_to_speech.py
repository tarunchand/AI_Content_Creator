class TTS:
    def __int__(self):
        pass

    def generate_audio(self, text):
        pass
