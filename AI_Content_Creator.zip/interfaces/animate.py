import cv2
import os
from PIL import Image
from utils.file_utility import FileUtility
from config.config import Config


class Animate:

    def __init__(self):
        pass

    def animate(self, image_path):
        pass

    @staticmethod
    def convert_video_to_frames(video_path, prefix_path):
        video = cv2.VideoCapture(video_path)
        FileUtility.create_directory(prefix_path)
        frame_count = 0
        while video.isOpened():
            ret, frame = video.read()
            if ret:
                frame_path = os.path.join(prefix_path, f"frame_{frame_count:05d}.jpg")
                cv2.imwrite(frame_path, frame)
                frame_count += 1
            else:
                break
        video.release()

    @staticmethod
    def resize_images(prefix_path):
        for file in os.listdir(prefix_path):
            with Image.open(os.path.join(prefix_path, file)) as image:
                resized_image = image.resize(Config.IMAGE_RESOLUTION)
                resized_image.save(os.path.join(prefix_path, file))


class ParallaxAnimator(Animate):
    def __init__(self):
        super().__init__()

    def animate(self, image_path):
        pass
