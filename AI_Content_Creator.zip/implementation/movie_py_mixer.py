import os
from interfaces.visual_audio_mixer import VisualAudioMixer, AnimationMixer
from moviepy.editor import ImageClip, ImageSequenceClip, AudioFileClip
from utils.global_media_handle import GlobalMediaHandle
from config.config import Config


class MoviePyMixer(VisualAudioMixer):
    def __init__(self):
        super().__init__()

    def convert(self, image_path, audio_path):
        image_clip = ImageClip(image_path)
        audio_clip = AudioFileClip(audio_path)
        video_clip = image_clip.set_audio(audio_clip)
        video_clip.duration = audio_clip.duration
        video_clip.fps = Config.VIDEO_FPS
        output_path = GlobalMediaHandle.get_next_video_file_path()
        video_clip.write_videofile(output_path)
        return output_path


class MoviePyAnimationMixer(AnimationMixer):
    def __init__(self, animator):
        super().__init__(animator)

    def convert(self, image_path, audio_path):
        audio_clip = AudioFileClip(audio_path)
        image_frames_dir = self.animator.animate(image_path)
        sequence = sorted([os.path.join(image_frames_dir, f)
                           for f in os.listdir(image_frames_dir)])
        sequence_len = len(sequence)
        image_pos = 0
        image_sequence = []
        total_frames = int(audio_clip.duration * Config.VIDEO_FPS)
        for i in range(total_frames):
            image_sequence.append(sequence[image_pos])
            image_pos = (image_pos + 1) % sequence_len
        video_clip = ImageSequenceClip(image_sequence, fps=Config.VIDEO_FPS)
        video_clip = video_clip.set_audio(audio_clip)
        video_clip.duration = audio_clip.duration
        video_clip.fps = Config.VIDEO_FPS
        output_path = GlobalMediaHandle.get_next_video_file_path()
        video_clip.write_videofile(output_path)
        return output_path

