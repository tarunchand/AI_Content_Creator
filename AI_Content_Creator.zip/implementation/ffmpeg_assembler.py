import subprocess
import shlex
from interfaces.video_assembler import VideoAssembler
from config.config import Config
from utils.file_utility import FileUtility


class FFMPEGAssembler(VideoAssembler):
    def __init__(self):
        super().__init__()

    def assemble(self, video_parts_path):
        with open(Config.TEMP_FILE, "w") as f:
            for video in video_parts_path:
                f.write(f"file '{video}'\n")
        command = f"ffmpeg -f concat -safe 0 -i {shlex.quote(Config.TEMP_FILE)} -c copy " \
                  f"{shlex.quote(Config.OUTPUT_VIDEO_FILE)}"
        print(command)
        subprocess.run(command, shell=True)
        FileUtility.delete_file(Config.TEMP_FILE)
        return Config.OUTPUT_VIDEO_FILE
