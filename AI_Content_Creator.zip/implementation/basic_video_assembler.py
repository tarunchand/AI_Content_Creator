from interfaces.video_assembler import VideoAssembler
from config.config import Config
from utils.console_utility import Console


class BasicVideoAssembler(VideoAssembler):
    def __init__(self):
        super().__init__()

    def assemble(self, video_parts_path):
        with open(Config.OUTPUT_VIDEO_FILE, 'wb') as output:
            for index, file in enumerate(video_parts_path):
                print(file)
                Console.info('Assembling Video - Progress : ({}/{})'.format(index + 1, len(video_parts_path)))
                with open(file, 'rb') as video:
                    content = video.read()
                    output.write(content)
        return Config.OUTPUT_VIDEO_FILE
