import os

from interfaces.animate import ParallaxAnimator
from utils.file_utility import FileUtility


class LeiApixAnimator(ParallaxAnimator):
    def __init__(self):
        super().__init__()

    def animate(self, image_path):
        prefix_path, ext = self.generate_animated_video(image_path)
        video_file = prefix_path + ext
        FileUtility.delete_dir_tree(prefix_path)
        self.convert_video_to_frames(video_file, prefix_path)
        self.resize_images(prefix_path)
        return prefix_path

    @staticmethod
    def generate_animated_video(image_path):
        prefix_path = os.path.splitext(image_path)[0]
        return prefix_path, '.mp4'
