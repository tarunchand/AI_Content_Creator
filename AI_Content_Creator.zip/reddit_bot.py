import praw

reddit = praw.Reddit(
    client_id='tMpETGItPImmk2_6dx9T9Q',
    client_secret='XzuMUCml1T_KVkzzlM8pK6ZbZQK9Tw',
    username='Icy-Goat304',
    password='Devil@123',
    user_agent='M47'
)

popular_subreddits = set()


def get_popular_subreddits():
    global popular_subreddits
    for subreddit in reddit.subreddits.default(limit=None):
        print(subreddit)
        if subreddit.subscribers > 100000:
            popular_subreddits.add(subreddit.display_name)
    temp = reddit.subreddit('all')
    temp.submit()