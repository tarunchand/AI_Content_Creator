

from PIL import Image

im = Image.open('test.jpg')
width, height = 1024, 1024

left = 0
top = 0
right = 1024
bottom = 1024

#  To generate zoomed image frames

frames = 30

final_image_dimensions = 512

decrement_factor = (width - final_image_dimensions) / (2 * frames)

frames_list = []

for i in range(frames):
    left += decrement_factor
    top += decrement_factor
    right -= decrement_factor
    bottom -= decrement_factor
    frames_list.append(im.crop((left, top, right, bottom)))


