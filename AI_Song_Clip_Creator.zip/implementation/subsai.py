from interfaces.subtitle_generator import SubtitleGenerator
from subsai import SubsAI
from config.config import Config
from utils.string_utils import StringUtils


class SubsAiSubtitleGenerator(SubtitleGenerator):
    def __init__(self):
        super().__init__()

    def generate(self, audio_path):
        subs_ai = SubsAI()
        model = 'linto-ai/whisper-timestamped'
        model_config = dict(
            {
                'model_type': 'base',
                'segment_type': 'word',
                'device': 'cuda:0'
            }
        )
        model = subs_ai.create_model(model, model_config)
        subs = subs_ai.transcribe(audio_path, model)
        subs.save(Config.OUTPUT_SRT_FILE)
        final_subs = []
        for sub in subs:
            text = sub.text
            alpha_text = StringUtils.get_alpha(text)
            if len(alpha_text) > 0:
                final_subs.append((sub.end, alpha_text.lower()))
        return final_subs
