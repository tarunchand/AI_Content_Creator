import os
import cv2

from interfaces.animate import ParallaxAnimator
from utils.file_utility import FileUtility
from utils.media_utils import MediaUtils
from config.config import Config


class LeiApixAnimator(ParallaxAnimator):
    def __init__(self):
        super().__init__()
        self.total_frames = Config.TOTAL_ANIMATION_FRAMES # 89

    def animate(self, image_path):
        prefix_path, ext = self.generate_animated_video(image_path)
        video_file = prefix_path + ext
        FileUtility.delete_dir_tree(prefix_path)
        MediaUtils.convert_video_to_frames(video_file, prefix_path)
        MediaUtils.resize_images(prefix_path)
        return prefix_path

    def generate_animated_video(self, image_path):
        prefix_path = os.path.splitext(image_path)[0]
        if Config.TEST_MODE and not os.path.exists(prefix_path + '.mp4'):
            video_file = prefix_path + '.mp4'
            duration = int(self.total_frames * 1000 / Config.VIDEO_FPS)
            MediaUtils.generate_video_from_image(image_path, video_file, duration)
        return prefix_path, '.mp4'
