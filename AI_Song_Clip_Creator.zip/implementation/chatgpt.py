import os
import shlex
from interfaces.llm import LLM
from revChatGPT.V1 import Chatbot
from utils.file_utility import FileUtility
from interfaces.prompt_template import PromptTemplate
from interfaces.paragraph_splitter import ParagraphSplitter
from interfaces.image_prompt_generator import ImagePromptGenerator
from config.config import Config
from implementation.hashing import MD5
from utils.console_utility import Console


class ChatGPT(LLM):
    cache = FileUtility.load_json_file(Config.CHATGPT_CACHE)

    def __init__(self):
        chatgpt_auth = FileUtility.load_json_file(os.path.join('config', 'chatgpt_auth.json'))
        self.chatgpt = Chatbot(config={
            "access_token": chatgpt_auth["accessToken"]
        })
        self.hash_fn = MD5()

    def ask(self, prompt: str):
        hashed_prompt = self.hash_fn.hash(prompt)
        if hashed_prompt in self.cache['chatgpt']:
            return self.cache['chatgpt'][hashed_prompt]
        response = ""
        for data in self.chatgpt.ask(
                prompt
        ):
            response = data["message"]
        if Config.EDIT_PROMPTS:
            if Console.ask('Would you like to edit the response ?(y/n)').lower() == 'y':
                data = '[PROMPT]' + '\n' + prompt + '\n\n' + '[RESPONSE]' + '\n' + response + '\n\n'
                FileUtility.write_file_data(Config.TEMP_FILE, data)
                os.system('vi {}'.format(shlex.quote(Config.TEMP_FILE)))
                response = FileUtility.read_file_data(Config.TEMP_FILE).split('[RESPONSE]')[1].strip()
        self.cache['chatgpt'][hashed_prompt] = response
        return response

    @staticmethod
    def save_cache():
        Console.info('Saving chatgpt cache')
        FileUtility.dump_json_file(Config.CHATGPT_CACHE, ChatGPT.cache)


class ChatGPTParagraphSplitter(ParagraphSplitter):
    def __init__(self, text):
        super().__init__(ChatGPT(), ChatGPTParagraphTemplate(), text)


class ChatGPTParagraphTemplate(PromptTemplate):
    def __init__(self):
        super().__init__()

    def get_prompt(self, text):
        return 'Split the below text into meaningful paragraphs:\n\n' + text + '\n'


class ChatGPTImagePromptGenerator(ImagePromptGenerator):
    def __init__(self, paragraphs):
        super().__init__(ChatGPT(), ChatGPTImageGenPromptTemplate(), paragraphs)


class ChatGPTImageGenPromptTemplate(PromptTemplate):
    def __init__(self):
        super().__init__()

    def get_prompt(self, text):
        if Config.CAMERA_TYPE == 'portrait':
            additional_text = ''
        else:
            additional_text = '\n"camera_lens_type": <wide angle or medium angle or closeup>,'
        return '''
        DALLE-2 is a text-to-image AI model which generates an image from a text prompt.
I want you to write one DALLE-2 prompt which exactly describes an IDEA. The prompt should be in JSON format. 

Below is the format of the prompt
{
"landscape": <description of the landscape in the below IDEA using only nouns and adjectives>,  
"entity": <description of persons or objects or animals or 
any entities in the below IDEA using only nouns, adjectives or verbs or adverbs>, 
"modifiers": <descriptive keywords of the idea - mood, style, lighting, and other aspects of the scene in the idea 
using only adjectives>,''' + additional_text + '''
"style_of_photograph":<style of photograph>
}

Rules :- 
Pronouns, Preposition, Conjunction and Interjection should not be used in the prompts

Below is the idea you have to write prompt for
IDEA : ''' + text


class ChatGPTMotivationalTemplate(PromptTemplate):
    def __init__(self):
        super().__init__()

    def get_prompt(self, text):
        return text


class ChatGPTMotivationalPersonTemplate(PromptTemplate):
    def __init__(self):
        super().__init__()

    def get_prompt(self, text):
        return text


class ChatGPTMysteryTemplate(PromptTemplate):
    def __init__(self):
        super().__init__()

    def get_prompt(self, text):
        return text


class ChatGPTHorrorTemplate(PromptTemplate):
    def __init__(self):
        super().__init__()

    def get_prompt(self, text):
        return text


class ChatGPTEducationalTemplate(PromptTemplate):
    def __init__(self):
        super().__init__()

    def get_prompt(self, text):
        return text
