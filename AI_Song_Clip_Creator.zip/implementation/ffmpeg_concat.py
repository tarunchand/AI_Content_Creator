import os
import random
import shlex
from interfaces.transitions import Transitions
from config.config import Config
from utils.media_utils import MediaUtils, GlobalMediaHandle
from utils.console_utility import Console


class FFMPEGConcatTransition(Transitions):
    def __init__(self):
        super().__init__()
        self.transitions = [
            "circle", "polar_function",
            "wipeRight", "circleopen", "directionalwarp",
            "LinearBlur", "PolkaDotsCurtain", "wipeUp",
            "angular", "colorphase", "directionalwipe", "flyeye", "luma",
            "SimpleZoom", "GlitchDisplace", "luminance_melt", "Radial",
            "undulatingBurnOut", "ZoomInCircles", "Bounce",
            "GlitchMemories", "morph", "BowTieHorizontal", "CrazyParametricFun", "DoomScreenTransition",
            "GridFlip", "Mosaic", "randomsquares", "squareswire",
            "BowTieVertical", "crosshatch", "doorway", "heart",
            "squeeze", "WaterDrop", "crosswarp", "Dreamy", "hexagonalize", "multiply_blend",
            "wind", "burn", "CrossZoom", "DreamyZoom",
            "ripple", "windowblinds", "ButterflyWaveScrawler",
            "cube", "perlin", "StereoViewer",
            "windowslice", "cannabisleaf", "InvertedPageCurl",
            "pinwheel", "rotate_scale_fade", "swap", "wipeDown", "CircleCrop",
            "kaleidoscope", "pixelize", "Swirl", "wipeLeft"
        ]
        self.total_transition_ms = 1500

    def generate_transition(self, image1, image2, duration=500):
        image1_video_path = os.path.join(Config.CURRENT_OUTPUT_DIR, "image1.mp4")
        image2_video_path = os.path.join(Config.CURRENT_OUTPUT_DIR, "image2.mp4")
        MediaUtils.generate_video_from_image(image1, image1_video_path)
        MediaUtils.generate_video_from_image(image2, image2_video_path)
        transition = random.choice(self.transitions)
        Console.info("Generating Transition: {}".format(transition))
        output_path = os.path.join(Config.CURRENT_OUTPUT_DIR, "transition.mp4")
        concat_command = "ffmpeg-concat -t {} -d {} -o {} {} {}".format(transition, duration, shlex.quote(output_path),
                                                                        shlex.quote(image1_video_path),
                                                                        shlex.quote(image2_video_path))
        os.system(concat_command)
        transition_video_dir_path = GlobalMediaHandle.get_next_video_dir_path()
        MediaUtils.convert_video_to_frames(output_path, transition_video_dir_path)
        MediaUtils.resize_images(transition_video_dir_path)
        return transition_video_dir_path
