class LLM:
    def __int__(self):
        pass

    def ask(self, prompt: str):
        pass
