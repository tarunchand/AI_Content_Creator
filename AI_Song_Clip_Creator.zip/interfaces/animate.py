import os
from PIL import Image
from utils.file_utility import FileUtility
from config.config import Config


class Animate:

    def __init__(self):
        pass

    def animate(self, image_path):
        pass


class ParallaxAnimator(Animate):
    def __init__(self):
        super().__init__()

    def animate(self, image_path):
        pass
