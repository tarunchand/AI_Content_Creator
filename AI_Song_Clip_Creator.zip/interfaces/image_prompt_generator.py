import json
from utils.console_utility import Console
from config.config import Config


class ImagePromptGenerator:
    def __init__(self, llm, prompt_template, paragraphs):
        self.llm = llm
        self.prompt_template = prompt_template
        self.paragraphs = paragraphs

    def generate_prompt(self):
        prompts = []
        i = 1
        n = len(self.paragraphs)
        for paragraph in self.paragraphs:
            Console.info('Generating Image Prompt : Part - ({}/{})'.format(i, n))
            prompt_template = self.prompt_template.get_prompt(paragraph)
            response = self.llm.ask(prompt_template)
            response_dict = json.loads(response)
            camera_lens_type = ''
            if Config.CAMERA_TYPE != 'portrait':
                camera_lens_type = response_dict['camera_lens_type']
            response_dict['modifiers'] = response_dict['modifiers'].split(',')
            if len(response_dict['modifiers']) > Config.IMAGE_PROMPT_MAX_MODIFIERS:
                response_dict['modifiers'] = ','.join(response_dict['modifiers'][:Config.IMAGE_PROMPT_MAX_MODIFIERS])
            else:
                response_dict['modifiers'] = ','.join(response_dict['modifiers'])
            prompt = Config.STYLE + Config.CAMERA_TYPE + ', ' + response_dict['landscape'] + ', ' \
                + response_dict['entity'] + ', ' + response_dict['modifiers'] + ', ' \
                + camera_lens_type + ', ' + response_dict['style_of_photograph']
            prompts.append(prompt)
            i += 1
        return prompts
