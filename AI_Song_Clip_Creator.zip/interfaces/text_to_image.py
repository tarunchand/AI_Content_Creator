class TTI:
    def __init__(self):
        pass

    def generate_image(self, prompt):
        pass
