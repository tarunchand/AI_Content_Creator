class Transitions:

    def __int__(self):
        pass

    def generate_transition(self, image1, image2, duration):
        pass
