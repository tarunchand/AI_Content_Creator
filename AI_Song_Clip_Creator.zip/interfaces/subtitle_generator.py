class SubtitleGenerator:
    def __init__(self):
        pass

    def generate(self, audio_path):
        pass
