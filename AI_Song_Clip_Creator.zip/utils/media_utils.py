import os
import cv2
from PIL import Image
from config.config import Config
from utils.file_utility import FileUtility


class GlobalMediaHandle:
    audio_file_prefix = os.path.join(Config.CURRENT_OUTPUT_DIR, Config.AUDIO_SEQUENCE_PREFIX)
    image_dir_prefix = os.path.join(Config.CURRENT_OUTPUT_DIR, Config.IMAGE_SEQUENCE_PREFIX)
    video_file_prefix = os.path.join(Config.CURRENT_OUTPUT_DIR, Config.VIDEO_SEQUENCE_PREFIX)
    current_audio_handle = 0
    current_image_handle = 0
    current_video_handle = 0

    @staticmethod
    def get_next_image_dir_path():
        GlobalMediaHandle.current_image_handle += 1
        res = GlobalMediaHandle.image_dir_prefix + str(GlobalMediaHandle.current_image_handle)
        FileUtility.create_directory(res)
        return res

    @staticmethod
    def get_next_video_dir_path():
        GlobalMediaHandle.current_video_handle += 1
        res = GlobalMediaHandle.video_file_prefix + str(GlobalMediaHandle.current_video_handle)
        FileUtility.create_directory(res)
        return res


class MediaUtils:

    @staticmethod
    def convert_video_to_frames(video_path, prefix_path):
        video = cv2.VideoCapture(video_path)
        FileUtility.create_directory(prefix_path)
        frame_count = 0
        while video.isOpened():
            ret, frame = video.read()
            if ret:
                frame_path = os.path.join(prefix_path, f"frame_{frame_count:05d}.jpg")
                cv2.imwrite(frame_path, frame)
                frame_count += 1
            else:
                break
        video.release()

    @staticmethod
    def resize_images(prefix_path):
        for file in os.listdir(prefix_path):
            with Image.open(os.path.join(prefix_path, file)) as image:
                resized_image = image.resize(Config.IMAGE_RESOLUTION)
                resized_image.save(os.path.join(prefix_path, file))

    @staticmethod
    def generate_video_from_image(image_path, output_path, duration=1000):
        image = cv2.imread(image_path)
        height, width, _ = image.shape
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        video_writer = cv2.VideoWriter(output_path, fourcc, Config.VIDEO_FPS, (width, height))
        frame_count = int((duration / 1000) * Config.VIDEO_FPS)
        for i in range(frame_count):
            video_writer.write(image)
        video_writer.release()
