class StringUtils:

    @staticmethod
    def get_alpha(string):
        return ''.join(filter(str.isalpha, string))
