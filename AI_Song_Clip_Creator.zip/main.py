import warnings

warnings.filterwarnings("ignore")
import os
import random
import shlex
from implementation.bing import BingImageGenerator
from implementation.chatgpt import ChatGPT, ChatGPTImagePromptGenerator
from utils.console_utility import Console
from implementation.subsai import SubsAiSubtitleGenerator
from implementation.ffmpeg_concat import FFMPEGConcatTransition
from implementation.leiapix_animator import LeiApixAnimator
from utils.file_utility import FileUtility
from config.config import Config
from utils.string_utils import StringUtils
from moviepy.editor import ImageSequenceClip, AudioFileClip, VideoFileClip, CompositeVideoClip, TextClip
from moviepy.video.tools.subtitles import SubtitlesClip


def get_timestamps_for_paragraphs(paragraphs, subtitles):
    sub_index = 0
    end_times = []
    for paragraph in paragraphs:
        paragraph_words = paragraph.split(' ')
        words = []
        for word in paragraph_words:
            word = StringUtils.get_alpha(word)
            if len(word) > 0:
                words.append(word.lower())
        words = words[::-1]
        is_found = False
        for i in range(len(words)):
            sub_start_index = sub_index
            while sub_index < len(subtitles):
                if (words[i] == subtitles[sub_index][1]) and \
                        confirm_subtitle_match(words[i:], subtitles[sub_start_index:sub_index + 1]):
                    actual_sub_index = sub_index + i
                    if actual_sub_index >= len(subtitles):
                        end_times.append(subtitles[sub_index][0])
                    else:
                        end_times.append(subtitles[actual_sub_index][0])
                    sub_index = actual_sub_index
                    is_found = True
                    break
                sub_index += 1
            if is_found:
                break
            sub_index = sub_start_index
    return end_times


def confirm_subtitle_match(current_words_reversed, current_subtitles):
    if abs(len(current_words_reversed) - len(current_subtitles)) > 4:
        return False
    last_5_words = current_words_reversed[:5]
    last_5_subtitles = [subtitle[1] for subtitle in current_subtitles[-5:]]
    last_5_words_dict = dict()
    for word in last_5_words:
        if word in last_5_words_dict:
            last_5_words_dict[word] += 1
        else:
            last_5_words_dict[word] = 1
    total_mismatch_count = 0
    for word in last_5_subtitles:
        if word in last_5_words_dict:
            last_5_words_dict[word] -= 1
        else:
            total_mismatch_count += 1
    for word in last_5_words_dict.keys():
        total_mismatch_count += abs(last_5_words_dict[word])
    if total_mismatch_count > 4:
        return False
    return True


def generate_video(image_dirs, timestamps):
    transition = FFMPEGConcatTransition()
    transition_frames = int(transition.total_transition_ms / 1000 * Config.VIDEO_FPS)
    animation = LeiApixAnimator()
    previous_timestamp = 0
    previous_frame = None
    final_frame_list = []
    for i, timestamp in enumerate(timestamps):
        Console.info(f'Generating Video : Part - ({i + 1}/{len(timestamps)})')
        if timestamp == timestamps[0] or timestamp == timestamps[-1]:
            total_transition_ms = int(transition.total_transition_ms / 2)
        else:
            total_transition_ms = transition.total_transition_ms
        total_time_ms = timestamp - previous_timestamp
        if total_time_ms - total_transition_ms > 0:
            total_time_ms -= total_transition_ms
        frame_count = get_frames_count(total_time_ms, animation.total_frames, Config.BING_IMAGE_CREATOR_RESULTS_LEN,
                                       transition_frames)
        frames_list = []
        image_dir = image_dirs[i]
        previous_frame_internal = None
        for j in range(len(frame_count)):
            image_path = os.path.join(image_dir, f'{j % Config.BING_IMAGE_CREATOR_RESULTS_LEN}.jpeg')
            animated_image_dir = animation.animate(image_path)
            sequence = sorted([os.path.join(animated_image_dir, f)
                               for f in os.listdir(animated_image_dir)])
            sequence_len = len(sequence)
            if previous_frame_internal is not None:
                transition_dir = transition.generate_transition(previous_frame_internal, sequence[0])
                transition_sequence = sorted([os.path.join(transition_dir, f)
                                              for f in os.listdir(transition_dir)])
                frames_list.extend(transition_sequence)
            for k in range(frame_count[j]):
                frames_list.append(sequence[k % sequence_len])
            previous_frame_internal = frames_list[-1]
        if previous_frame is not None:
            transition_dir = transition.generate_transition(previous_frame, frames_list[0])
            sequence = sorted([os.path.join(transition_dir, f)
                               for f in os.listdir(transition_dir)])
            final_frame_list.extend(sequence)
        final_frame_list.extend(frames_list)
        previous_timestamp = timestamp
        previous_frame = frames_list[-1]
    video_clip = ImageSequenceClip(final_frame_list, fps=Config.VIDEO_FPS)
    audio_clip = AudioFileClip(Config.INPUT_AUDIO)
    video_clip = video_clip.set_audio(audio_clip)
    video_clip.duration = audio_clip.duration
    video_clip.fps = Config.VIDEO_FPS
    text_clip = lambda txt: TextClip(txt, font=Config.SUBTITLE_FONT,
                                     fontsize=Config.SUBTITLE_FONT_SIZE, color=Config.SUBTITLE_FONT_COLOR,
                                     stroke_color=random_color(), stroke_width=Config.SUBTITLE_STROKE_WIDTH)
    subtitles = SubtitlesClip(Config.OUTPUT_SRT_FILE, make_textclip=text_clip)
    subtitles.set_fps(video_clip.fps)
    video_width, video_height = video_clip.size
    # subtitles_y = video_height * 3 // 4
    subtitles = subtitles.set_position((Config.SUBTITLE_POSITION, Config.SUBTITLE_POSITION))
    subtitles = subtitles.set_duration(video_clip.duration)
    final_clip = CompositeVideoClip([video_clip, subtitles])
    final_clip.write_videofile(Config.OUTPUT_VIDEO_FILE)
    return Config.OUTPUT_VIDEO_FILE


def get_frames_count(total_time_ms, max_frames, max_images, transition_frames):
    total_frames = int((total_time_ms / 1000) * Config.VIDEO_FPS)
    frames_per_image = int((total_frames - ((max_images - 1) * transition_frames)) / max_images)
    if frames_per_image < max_frames:
        frames_per_image = max_frames
    frames_count = [frames_per_image]
    total_frames -= frames_per_image
    while total_frames >= (frames_per_image + transition_frames):
        total_frames -= transition_frames
        frames_count.append(frames_per_image)
        total_frames -= frames_per_image
    frames_count[-1] += total_frames
    return frames_count


def main():
    FileUtility.create_directory(Config.CURRENT_OUTPUT_DIR)
    paragraphs = FileUtility.read_file_data(Config.INPUT_STORY).split('\n')
    Console.info('Generating prompts')
    prompts = ChatGPTImagePromptGenerator(paragraphs).generate_prompt()
    Console.info('Generating images')
    image_dirs = []
    image_generator = BingImageGenerator()
    for prompt in prompts:
        image_dirs.append(image_generator.generate_image(prompt))
    Console.info('Generating subtitles')
    subtitle_generator = SubsAiSubtitleGenerator()
    subtitles = subtitle_generator.generate(Config.INPUT_AUDIO)
    timestamps = get_timestamps_for_paragraphs(paragraphs, subtitles)
    if len(timestamps) != len(paragraphs):
        Console.info(timestamps)
        Console.error('Could not find all timestamps')
        exit(1)
    if Console.ask('Would you like to edit the subtitles ?(y/n)').lower() == 'y':
        os.system('vi {}'.format(shlex.quote(Config.OUTPUT_SRT_FILE)))
    Console.info('Generating Video')
    final_video = generate_video(image_dirs, timestamps)
    Console.info('Final video generated at {}'.format(final_video))
    os.system('cvlc {}'.format(shlex.quote(final_video)))


def random_color():
    r = random.randint(0, 255)
    g = random.randint(0, 255)
    b = random.randint(0, 255)
    return "#{:02x}{:02x}{:02x}".format(r, g, b)


def test_subs():
    FileUtility.create_directory(Config.CURRENT_OUTPUT_DIR)
    paragraphs = FileUtility.read_file_data(Config.INPUT_STORY).split('\n')
    subtitle_generator = SubsAiSubtitleGenerator()
    subtitles = subtitle_generator.generate(Config.INPUT_AUDIO)
    print(subtitles)
    input('Press enter to continue')
    timestamps = get_timestamps_for_paragraphs(paragraphs, subtitles)
    print(timestamps)
    return paragraphs, timestamps


def test_video_gen():
    paragraphs, timestamps = test_subs()
    FileUtility.copy_dir_tree(Config.TEST_DIR, Config.CURRENT_OUTPUT_DIR)
    image_dirs = [
        os.path.join(Config.CURRENT_OUTPUT_DIR, 'image_1'),
        os.path.join(Config.CURRENT_OUTPUT_DIR, 'image_2'),
        os.path.join(Config.CURRENT_OUTPUT_DIR, 'image_3'),
    ]
    generate_video(image_dirs, timestamps)


'''
def test_burn_subtitles():
    video_path = '/home/infernal/PycharmProjects/AI_Song_Clip_Creator/output/2023-06-27 16:14:29/output.mp4'
    srt_path = '/home/infernal/PycharmProjects/AI_Song_Clip_Creator/output/2023-06-27 16:14:29/output.srt'
    video_clip = VideoFileClip(video_path)
    font = 'assets/font_6.ttf'
    text_clip = lambda txt: TextClip(txt, font=font,
                                     fontsize=130, color='white',
                                     stroke_color=random_color(), stroke_width=3.0)
    subtitles = SubtitlesClip(srt_path, make_textclip=text_clip)
    subtitles.set_fps(video_clip.fps)
    video_width, video_height = video_clip.size
    subtitles_y = video_height * 3 // 4
    subtitles = subtitles.set_position(("center", 'center'))
    subtitles = subtitles.set_duration(video_clip.duration)
    final_clip = CompositeVideoClip([video_clip, subtitles])
    final_clip.write_videofile('res.mp4')
'''


if __name__ == '__main__':
    try:
        main()
    except (KeyboardInterrupt, OSError, Exception) as ex:
        Console.error(ex)
    finally:
        ChatGPT.save_cache()
        BingImageGenerator.save_cache()
